exports.handler = async (event) => {
    console.log(123);
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from LinhClass Lambda!'),
    };
    return response;
};
